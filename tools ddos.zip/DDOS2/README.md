# DDoS-Ripper

# What is a DDoS Attack?
A Distributable Denied-of-Service (DDOS) attack server that cuts off targets or surrounding infrastructure in a flood of Internet traffic

DDoS attacks achieve effectiveness using multiple compromised computer systems as a source of attack traffic. Search engines may include computers and other network resources such as IoT devices.
From a higher level, the DDOS attack is like an unexpected traffic jam stuck on a highway, preventing regular traffic from reaching its destination.

## NOTE (Please, make sure you have installed python 3 )



## USGAE
`python3 DRipper.py -s [ip Address] -t 135`

`example: python3 DRipper.py -s 0.00.00.00 -t 135`

## For Debian-based GNU/Linux distributions
To use the application, type in the following commands in GNU/Linux terminal.

`$ ls`
`$ python3 DRipper.py` OR `python2 DRipper.py`


# Note:
If you find any problems than please write on issue github and to our Telegram Group. Don't use for revenge! Make sure your anonymity!
It's made for just testing purpose.
We are not responsible for any abuse or damage caused by this program. Only for Educational Purpose.
Thanks.
 
## Requirments ▶

●🖥Linux OS( Kali 🐉 Ubuntu )

●📱Termux >

●🖥Windows

●🖥MAC

